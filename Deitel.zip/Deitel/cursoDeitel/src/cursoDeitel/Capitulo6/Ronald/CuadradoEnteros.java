package cursoDeitel.Capitulo6.Ronald;

import java.awt.Container;
import javax.swing.*;

public class CuadradoEnteros extends JApplet {
	
	//configurar GUI y calcular los cuadrados de los enteros del 1 al 10
	
	public void init() {
		
	// objetos JTextArea para mostrar resultados
		
		JTextArea areaSalida = new JTextArea();
		
		//obtener panel de contenido del applets (area visible del componente de la GUI)
		
		Container contenedor = getContentPane();
		
		//adjuntar areaSalida al contenedor
		
		contenedor.add(areaSalida);
		
		int resultado;   //guardar el resultado de la llamada al metodo cuadrado
		
		String salida = " ";  //objeto string que contiene los resultados
		
		//iterar 10 veces
		
		for (int contador = 1; contador <=  10; contador++) {
			
			resultado = cuadrado(contador); //llamada al metodo
			
			//anexar resultado al objeto string salida
			
			salida += "El cuadrado de " + contador + " es "+ resultado + "\n";
		}//fin de la instruccion for
		
		
		areaSalida.setText(salida); //colocar los resultados en el objeto JTextArea
		
		
		
	}//fin del metodo init
	
	//declaracion del metodo cuadrado
	
	public int cuadrado (int y) {
		
		return y * y; //devolver cuadrado de y
		
	}//fin del metodo cuadrado

}
