
//programa para saber que numero es mayor entre 3 ingresados poir el usuario
package cursoDeitel.Capitulo6.Ronald;
import java.awt.Container;
import javax.swing.*;

public class PruebaMaximo extends JApplet{
//inicializar el applet, obtener la entrada del usuario y inicializar GUI
	
	public void init() {
		
	//obtendremos los numeros del usuario por medio de la entrada
		
		String s1 = JOptionPane.showInputDialog("Escriba el primer valor de punto flotante: ");
		String s2 = JOptionPane.showInputDialog("Escriba el segundo valor de punto flotante: ");
		String s3 = JOptionPane.showInputDialog("escriba el tercer valor de punto flotante: ");
		
		//convertir la entrada del susuario en valores double
		
		double numero1 = Double.parseDouble(s1);
		double numero2 = Double.parseDouble(s2);
		double numero3 = Double.parseDouble(s3);
		
		//usamos el metodo que va a hacer la comparacion
		
		double max = maximo (numero1,numero2,numero3);//llamada al metodo
		
		//crear objeto JTextArea para mostrar los resultados
		
		JTextArea areaSalida = new JTextArea();
		
		//mostrar los numeros y el valor maximo
		
		areaSalida.setText("numero1: " + numero1 + "\n"+ 
		"numero2: " + numero2 + "\n" + "numero3: " + numero3 + "\n" + 
				"el mayor de los numeros es: " + max);
		
		//obtener el area visible del applet para componentes GUI
		
		Container contenedor =  getContentPane();
		
		//adjuntar area de salida al contenedor
		
		contenedor.add(areaSalida);
		
	}//fin del metodo init
	
	/*el metodo maximo utiliza el metodo max de la clase Math para
	 * determinar el valor maximo
	 */
	
	public double maximo(double x, double y, double z){//inicio metodo maximo
		
	return Math.max(x, Math.max(y, z));
	
	}//fin del metodo maximo

}//fin de la clase PruebaMaximo
