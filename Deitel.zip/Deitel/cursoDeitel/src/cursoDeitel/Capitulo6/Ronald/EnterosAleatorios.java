package cursoDeitel.Capitulo6.Ronald;
import javax.swing.JOptionPane;

public class EnterosAleatorios {
	public static void main(String args[]) {
		
		int valor;
		String salida = " ";
		
		//vamos a iterar 20 veces
		
		for (int contador = 1; contador <= 20; contador++) {
			
			//elegir numeros aleatorios entre 1 y 6
			
			valor = 1 + (int)(Math.random()*6);
			
			salida += valor + " ";//anexar valor a salida
			
			//si el contador es divisible entre 5, anexar una nuevalinea a String salida
			
			if (contador%5 == 0) {
				
				salida += "\n";}
				
			}//fin de la instrucion for
			
			JOptionPane.showMessageDialog(null, salida, "20 numeros aleatorios del 1 al 6", JOptionPane.INFORMATION_MESSAGE);
			
			System.exit(0);
		}
	

}
