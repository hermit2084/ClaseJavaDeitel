package cursoDeitel.capitulo4.Ronald;
//programa para el analisi de los resultados de un examen
import javax.swing.JOptionPane;


public class Analisis {

	public static void main(String[] args) {
		
	//inicializamos las variables
		
		int aprobados = 0;
		int reprobados = 0 ;
		int contadorEstudiantes = 1;
		int resultado;
		
		String entrada;
		String salida;
		
		
		//evaluaremos los resultados de 10 estudiantes
		
		while(contadorEstudiantes <= 10) {
			
			//pediremos el valor de la nota al estudiante
			
			entrada = JOptionPane.showInputDialog("Escriba el resultado: 1 = Aprobado, 2= Reprobado");
			
			//convertimos el resultado a entero
			
			resultado = Integer.parseInt(entrada);
			
			//si el resultado es 1 incrementamos el valor de los aprovados si no es asi el de los reprobados
			
			if (resultado == 1)
				aprobados = aprobados + 1;
			
			else 
				reprobados = reprobados + 1;
			
			//incrementamos el valor de los estudiantes
			
			contadorEstudiantes  = contadorEstudiantes + 1;
			
		}
		
		
		salida = "Aprobados: " + aprobados + "\n Reprobados:" + reprobados;
		
		//determinar si aprobaron mas de 8 estudiantes
		
		if (aprobados >= 8)
			salida = salida +  "\n Aumentar colegiatura";
		
		else
			salida = salida + "\n Repetir colegiatura";
		
		JOptionPane.showMessageDialog(null, salida, "Analisis de resultados del examen", JOptionPane.INFORMATION_MESSAGE);
		
		System.exit(0);

	}

}
