package cursoDeitel.capitulo4.Ronald;
import javax.swing.JOptionPane;

public class Calificacion {

	public static void main(String[] args) {
		//creamos las variables para guardar la nota del alumno
		
		String Nombre;
		String Calificacion;
		
		double Nota;
		
		
		//tomamos el nombre del alumno y su nota
		Nombre = JOptionPane.showInputDialog("ingrese el nombre del alumno");
		Calificacion = JOptionPane.showInputDialog("ingrese la nota de la materia: ");
		
		//comparamos la calificacion para ver si aprueba
		
		Nota = Double.parseDouble(Calificacion);
		
		//comparamos la nota
		
		if(Nota >= 6 && Nota <=10)
			JOptionPane.showMessageDialog(null, Nombre + "\n" +"felicitciones aprobo","Resultados", JOptionPane.INFORMATION_MESSAGE);
		
		else 
			JOptionPane.showMessageDialog(null,Nombre + "\n" + "lo lamentamos has reprobado","Resultados", JOptionPane.INFORMATION_MESSAGE);
		
		System.exit(0);
	}

}
