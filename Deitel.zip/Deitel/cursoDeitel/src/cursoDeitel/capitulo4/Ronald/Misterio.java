package cursoDeitel.capitulo4.Ronald;
import javax.swing.JOptionPane;

public class Misterio {

	public static void main(String[] args) {
		
		int y, x=1, total = 0;
		
		while (x <= 10) {
			
			y = x * x;
			System.out.println(y);
			total += y;
			++x;
		}
		
		System.out.println("El total es: " + total);
		
		JOptionPane.showMessageDialog(null,"el resultado es: "+ total, "El resultado total es", JOptionPane.INFORMATION_MESSAGE);
	}
	
}
