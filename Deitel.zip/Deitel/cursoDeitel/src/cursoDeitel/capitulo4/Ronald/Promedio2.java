package cursoDeitel.capitulo4.Ronald;
import javax.swing.JOptionPane;
import java.text.DecimalFormat;

public class Promedio2 {

	public static void main(String[] args) {
		
	int total;
	int contadorCalif;
	int calificacion;
	
	double promedio;
	
	String cadenaCalif;
	
	total = 0;
	contadorCalif = 0;
	
	//obtener la primera calificacion del usuario
	
	cadenaCalif = JOptionPane.showInputDialog("escriba la calificacion como entero o -1 para salir: ");
	
	calificacion = Integer.parseInt(cadenaCalif);
	
	while (calificacion != -1) {
		
		total = total + calificacion;
		contadorCalif = contadorCalif + 1;
		
		//obtener siguiente calificacion del usuario
		
		cadenaCalif = JOptionPane.showInputDialog("escriba la calificacion como entero  o -1 para salir: ");
		
	calificacion = Integer.parseInt(cadenaCalif);	
	}
	
	//fase de terminacion
	
	DecimalFormat dosDigitos = new DecimalFormat("0.00");
	
	//si el usuario introdujo al menos una calificacion
	
	if (contadorCalif != 0) {
		
		promedio = (double) total / contadorCalif;
		
		//mostrar el promedio con dos digitos de precision
		
		JOptionPane.showMessageDialog(null, "el promdio de la clase es: " + dosDigitos.format(promedio), "promedio de la clase", JOptionPane.INFORMATION_MESSAGE);
	
	}
	
	else
		
		JOptionPane.showMessageDialog(null, "No se introdujeron calificaciones", "Promedio de la clase", JOptionPane.INFORMATION_MESSAGE);
	
	System.exit(0);
	}
	
	

}
