package cursoDeitel.capitulo4.Ronald;

public class Misterio3 {

	public static void main(String[] args) {
		
		int fila = 10 , columna;
		
		while(fila>=1) {
			
			System.out.print(fila % 2 == 1 ? "<" : ">");
			--fila;
			//++columna;
		}
		
		--fila;
		System.out.println();

	}

}
