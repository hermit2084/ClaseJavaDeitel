package cursoDeitel.capitulo4.Ronald;

public class Incremento {

	public static void main(String[] args) {
		
		int c;
		
		//demostrar el uso de postincremento
		
		c = 5;
		
		System.out.println(c);
		System.out.println(c++);
		System.out.println(c);
		System.out.println(c++);
		
		System.out.println();
		
		//demostrar el uso del preincremento
		
		c = 7;
		
		System.out.println(c);
		System.out.println(--c);
		System.out.println(c);
		System.out.println(c--);

	}

}
