package cursoDeitel.capitulo4.Ronald;
import javax.swing.JOptionPane;

public class Calcular {

	public static void main(String[] args) {
		
		int suma,x;
		
		
		x = 1;
		suma = 0;
		
		while (x <= 10) {
		suma += x;
		++x;

	}
	

	JOptionPane.showMessageDialog(null, "El resultado es: " + suma, "El resultado del calculo", JOptionPane.INFORMATION_MESSAGE);
	System.exit(0);
}
}