package cursoDeitel.capitulo4.Ronald;
import javax.swing.JOptionPane;

public class Promedio1 {

	public static void main(String[] args) {
		
		int total;
		int contadorCalif;
		int calificacion;
		int promedio;
		
		String cadenaCalif;
		
		total = 0;
		contadorCalif = 1;
		
		while (contadorCalif <= 10) {
			
			cadenaCalif = JOptionPane.showInputDialog("escriba la calificacion como un entero: ");
			
			calificacion = Integer.parseInt(cadenaCalif);
			
			total = total + calificacion;
			
			contadorCalif =contadorCalif + 1;
			
		}
		
		
		promedio = total / 10;
		
		JOptionPane.showMessageDialog(null, "El promedio de la clase es: " + promedio, "Resultados de calificaciones", JOptionPane.INFORMATION_MESSAGE);
		
	System.exit(0);
	
	
	}

}
