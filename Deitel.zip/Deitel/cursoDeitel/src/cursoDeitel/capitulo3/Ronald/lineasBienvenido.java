package cursoDeitel.capitulo3.Ronald;

import java.awt.Graphics;
import javax.swing.JApplet;

public class lineasBienvenido extends JApplet{
	
	public void paint(Graphics g) {
		
		super.paint(g);
		
		g.drawLine(15, 10, 250, 10);
		
		g.drawLine(15, 30, 250, 30);
		
		g.drawString("�bienvenido a la programacion en java!", 25, 25);
		
		
	}

}
