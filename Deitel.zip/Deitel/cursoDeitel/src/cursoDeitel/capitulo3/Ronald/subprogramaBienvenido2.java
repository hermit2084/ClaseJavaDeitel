package cursoDeitel.capitulo3.Ronald;

import java.awt.Graphics;
import javax.swing.JApplet;

public class subprogramaBienvenido2 extends JApplet{
	
	public void paint (Graphics g) {
		
		super.paint(g);
		
		g.drawString("!bienvenido a", 25, 25 );
		g.drawString("la programacion en java�", 25, 40 );
	}

}
