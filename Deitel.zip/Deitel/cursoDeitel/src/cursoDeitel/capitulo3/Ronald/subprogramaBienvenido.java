package cursoDeitel.capitulo3.Ronald;
//primer applet en java

import java.awt.Graphics;
import javax.swing.JApplet;


public class subprogramaBienvenido extends JApplet{

	public void paint (Graphics g) {
		
		super.paint(g);
		
		g.drawString("bienvenido en la programacion en java", 25, 25);
		
	}

}
