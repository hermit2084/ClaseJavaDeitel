package cursoDeitel.Capitulo5.Ronald;
import javax.swing.*;

public class operadoresLogicos {

	public static void main(String[] args) {
		
		//creamos JTextArea para mostrar los resultados
		
		JTextArea areaSalida = new JTextArea(17,20);
		
		//adjuntar JTextArea a un JScrollPane, para desplazarse por los ressultados
		
		JScrollPane desplazador = new JScrollPane(areaSalida);
		
		//crear la tabla de la verdad para el operador && (AND condicional)
		
		String salida = "AND condicional (&&)" +
		"\nfalse && false: " + (false && false) +
		"\nfalse && true: " + (false && true) +
		"\ntrue && false: " + (true && false) +
		"\ntrue && true: " + (true && true);
		
		//crear la tabla de verdad para el operador || (OR condicional)
		
		salida += "\n\nOR condicional (||)" +
				"\nfalse || false: " + (false || false) +
				"\nfalse || true: " + (false || true) +
				"\ntrue || false: " + (true || false) +
				"\ntrue || true: " + (true || true);
		
		//crear la tabla de verdad para el operador l�gico & (AND l�gico booleno)
		
		salida += "\n\nAND l�gico booleano (&)" +
				"\nfalse & false: " + (false & false) +
				"\nfalse & true: " + (false & true) +
				"\ntrue & false: " + (true & false) +
				"\ntrue & true: " + (true & true);
		
		//crear la tabla de verdad para el operador l�gico | (OR inclusivo l�gico booleno)
		
				salida += "\n\nOR incluyente l�gico booleano (|)" +
						"\nfalse | false: " + (false | false) +
						"\nfalse | true: " + (false | true) +
						"\ntrue | false: " + (true | false) +
						"\ntrue | true: " + (true | true);
				
		//crear la tabla de verdad para el operador l�gico ^ (OR excluyente l�gico booleno)
				
				salida += "\n\nOR excluyente l�gico booleano (^)" +
						"\nfalse ^ false: " + (false ^ false) +
						"\nfalse ^ true: " + (false ^ true) +
						"\ntrue ^ false: " + (true ^ false) +
						"\ntrue ^ true: " + (true ^ true);
		
		//crear la tabla de verdad para el operador ! (negaci�n l�gica)
				
				salida += "\n\nNOT l�gico (!)" +
						"\n!false: " + (!false) +
						"\n!true: " + (!true);
				
		
		areaSalida.setText(salida);//colocar los resultados en el objeto JTextArea
		
		JOptionPane.showMessageDialog(null, desplazador, "Tablas de verdad", JOptionPane.INFORMATION_MESSAGE);
		
		System.exit(0); //terminar la aplicacion
				

	}

}
