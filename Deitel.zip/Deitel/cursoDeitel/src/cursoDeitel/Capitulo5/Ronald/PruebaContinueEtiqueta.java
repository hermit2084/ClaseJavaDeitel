package cursoDeitel.Capitulo5.Ronald;
import javax.swing.JOptionPane;

public class PruebaContinueEtiqueta {

	public static void main(String[] args) {
		
		String salida = "";
		
		siguienteFila://etiqueta de destino de la instrucci�n continue
			//contar 5 filas
			
			for (int fila = 1; fila <= 5; fila++) {//ciclo for de filas
		
			salida += "\n";
			
			//contador columnas porr filas
			
			for (int columna = 1; columna <= 10; columna++) {//inicio for columna
				
				//si la columna es mayor que la fila, empezar en la siguiente fila
				
				if (columna > fila)
					continue siguienteFila;
				
				salida +="* "; 
			}//fin del ciclo for de columnas
			}//fin del ciclo for de filas
		
		javax.swing.JOptionPane.showMessageDialog(null, salida, "Probando continue con una etiqueta", javax.swing.JOptionPane.INFORMATION_MESSAGE);
			
	System.exit(0);		

	}

}
