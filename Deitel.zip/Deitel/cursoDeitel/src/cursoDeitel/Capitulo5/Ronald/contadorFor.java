package cursoDeitel.Capitulo5.Ronald;
import java.awt.Graphics;
import javax.swing.JApplet;

public class contadorFor extends JApplet {
	
	public void paint(Graphics g) {
		
		super.paint(g);
		
		for(int contador = 1; contador <= 10; contador++) {
			
			g.drawLine(10, 10, 250, contador*10 );
		}
	}

}
