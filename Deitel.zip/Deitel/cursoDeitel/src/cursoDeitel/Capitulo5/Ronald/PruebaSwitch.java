package cursoDeitel.Capitulo5.Ronald;
//programa para que el usuario elija que quiere dibujar
import java.awt.Graphics;

import javax.swing.*;

public class PruebaSwitch extends JApplet {
	
	int opcion;//guardamos la opcion de la figura que el usuario quiere dibujar
	
	public void init() {
		
		String entrada;//la entrada del usuario
		
		//obtener la entrada del usuario
		
		entrada = JOptionPane.showInputDialog(
				
				"Escriba 1 para dibujar l�neas\n" +
				"Escriba 2 para dibijar cuadrados\n" +
				"Escriba 3 para dibujar circulos\n");
		
		opcion = Integer.parseInt(entrada);
		
	}//fin del metodo init
	
	//dibujar figuras en el fondo del applet
	
	
	public void paint(Graphics g) {
		
		super.paint(g);//llamamos al metodo paint heredado de JApplet
		
		for(int i = 0; i < 10; i++) {
			
			switch (opcion) {
			
			case 1 ://vamos a dibujar una linea
				g.drawLine(10,10,250,10 + i * 10);
				break;//fin del procesamiento del case
				
				
			case 2://vamos a dibujar cuadrados
				g.drawRect(10 + i * 10, 10 + i * 10, 50 + i * 10, 50 + i * 10);
				break; //fin del procesamiento case
				
			case 3: //vamos a dibujar circulos
				g.drawOval(10 + i * 10, 10 + i *10, 50 + i * 10, 50 + i * 10);
				break;//fin del procesamiento case
				
			default://dibujar cadena que se escribio un valos incorrectoincorrecto 
				g.drawString("Se escribio un valor incorrecto", 10, 20 + i * 15);
					
			
			}//fin metodo switch
			
		}//fin del metodo for
		
		
		
	}//fin metodo paint

}
