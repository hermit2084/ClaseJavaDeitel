package cursoDeitel.Capitulo5.Ronald;
import java.awt.Graphics;
import javax.swing.JApplet;

public class contadorWhile extends JApplet {

	public void paint(Graphics g) {
		
		super.paint( g );
		
		int contador = 1;
		
		while (contador <= 10) {
			
			g.drawLine(10, 10, 250, contador*10);
			++contador;
		}
		

	}

}
