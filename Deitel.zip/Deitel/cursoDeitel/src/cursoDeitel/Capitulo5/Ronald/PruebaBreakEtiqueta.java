package cursoDeitel.Capitulo5.Ronald;
import javax.swing.JOptionPane;

public class PruebaBreakEtiqueta {

	public static void main(String[] args) {
		
		String salida = " ";
		
		alto:{//bloque etiquetado
			
			//contar 10 filas
			
			for (int fila= 1; fila <= 10;  fila++) {//for externo
				
				for(int columna = 1; columna <= 5; columna++) {//ciclo for interno
					
					if(fila == 5)//si la fila es 5;
						break alto;//saltar al final del bloque alto
					
					salida += "*  ";
					
				}//fin ciclo for interno
				
				salida += "\n";
				
				
			}//fin ciclo for externo
			
			//la siguiente linea se evita
			
			salida += "\nLos ciclos terminaron normalmente";
		}//fin bloque etiquetdo
		
		JOptionPane.showMessageDialog(null, salida, "Probando break con una etiqueta", JOptionPane.INFORMATION_MESSAGE);
		System.exit(0);

	}

}
