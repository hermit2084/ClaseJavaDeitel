package cursoDeitel.Capitulo5.Ronald;
import javax.swing.JOptionPane;

public class PruebaContinue {

	public static void main(String[] args) {
		
		String salida = " ";
		
		for (int cuenta = 1; cuenta <= 10; cuenta++) {
			
			if (cuenta == 5)//si cuenta vale 5
				continue;
	salida += cuenta + " ";
				
		}//fin metodo for
		
		salida += "\nSe utliz� continue para evitar un 5";
		JOptionPane.showMessageDialog(null, salida);
		System.exit(0);
		

	}

}
