package cursoDeitel.Capitulo5.Ronald;
//terminacion de un  ciclo con break

import javax.swing.JOptionPane;

public class PruebaBreak {

	public static void main(String[] args) {
		
		String salida = "";
		int cuenta;
		
		for(cuenta = 1; cuenta <= 10; cuenta++) {
			
			if (cuenta == 5)//si cuenta vale 5
				break;
			
			salida += cuenta + " ";
		}//fin del metodo for

		
		salida += "\nSe sali� del ciclo en cuenta= "+ cuenta;
		JOptionPane.showMessageDialog(null, salida);
		
		System.exit(0);
	}

}
