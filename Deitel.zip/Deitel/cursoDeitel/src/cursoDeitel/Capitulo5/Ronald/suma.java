package cursoDeitel.Capitulo5.Ronald;
import javax.swing.JOptionPane;

public class suma {

	public static void main(String[] args) {
		
		int total = 0;
		
		for(int numero = 2; numero <= 100; numero +=2) {
			total += numero;
			
		}
		
		JOptionPane.showMessageDialog(null,"La suma es: " + total, "Suma de los enteros pares del 1 al 100",JOptionPane.INFORMATION_MESSAGE);

		System.exit(0);
	}

}
