package cursoDeitel.Capitulo5.Ronald;
import java.awt.Graphics;

import javax.swing.JApplet;

public class PruebaDoWhile extends JApplet {
	
	//dibujar lineas en el applet
	
	public void paint (Graphics g) {
		
		super.paint(g);
		
		int contador = 1;
		
		do {
			
			g.drawOval(110 - contador * 10, 110 - contador * 10, contador * 20, contador * 20);
			++contador;
		} while(contador <= 10);
	}

}
