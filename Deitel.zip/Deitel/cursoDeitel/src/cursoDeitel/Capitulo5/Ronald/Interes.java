package cursoDeitel.Capitulo5.Ronald;
import java.text.NumberFormat;
import java.util.Locale;

import javax.swing.JOptionPane;
import javax.swing.JTextArea;


public class Interes {

	public static void main(String[] args) {
		
		double cantidad;
		double principal = 1000.0;
		double tasa = 0.05;
		
		
		NumberFormat formatoMoneda = NumberFormat.getCurrencyInstance(Locale.US);
		
		JTextArea areaTextoSalida = new JTextArea();
		
		//establecemos los titulos de cada rublo en el texto
		
		areaTextoSalida.setText("A�o\t Cantidad en d�posito\n");
		
		//calcular la cantidad en deposito para cada uno de los diez a�os
		
		for (int anio = 1; anio <= 10; anio++) {
		cantidad = principal * Math.pow(1.0 + tasa, anio);
		
		//anexar una l�nea de tsxto a areaTextoSalida
		
		areaTextoSalida.append(anio + "\t" + formatoMoneda.format(cantidad) + "\n");
		
		}
		
		//mostrar resultados
		
		JOptionPane.showMessageDialog(null, areaTextoSalida,"inter�s compuesto",JOptionPane.INFORMATION_MESSAGE);
		System.exit(0);
	}

}
