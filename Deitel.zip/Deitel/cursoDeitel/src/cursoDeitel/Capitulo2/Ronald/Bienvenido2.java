package cursoDeitel.Capitulo2.Ronald;

public class Bienvenido2 {

	public static void main(String[] args) {
		System.out.println("�Bienvenido a");
		System.out.println("la programacion en java!");
	}

}
