package cursoDeitel.Capitulo2.Ronald;
import javax.swing.JOptionPane;
public class Producto {

	public static void main(String[] args) {

String primerNumero;
String segundoNumero;
String tercerNumero;

int numero1;
int numero2;
int numero3;
int Resultado;


primerNumero = JOptionPane.showInputDialog("introduzca el primer numero entero:");
segundoNumero = JOptionPane.showInputDialog("ingrese el segundo numero entero:");
tercerNumero = JOptionPane.showInputDialog("ingrese el tercer numero entero:");

numero1 = Integer.parseInt(primerNumero);
numero2 = Integer.parseInt(segundoNumero);
numero3 = Integer.parseInt(tercerNumero);

Resultado = numero1*numero2*numero3;

JOptionPane.showMessageDialog(null, "el resultado del prroducto es: " + Resultado, "Resultado", JOptionPane.PLAIN_MESSAGE);

System.exit(0);

	}

}
