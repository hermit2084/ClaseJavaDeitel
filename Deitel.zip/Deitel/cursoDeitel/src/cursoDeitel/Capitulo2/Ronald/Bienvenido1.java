package cursoDeitel.Capitulo2.Ronald;

//Bienvenido1.java
//programa para imprimir texto


public class Bienvenido1 {
	
	//el metodo main empieza la ejecuci�n de la aplicacion en java

	public static void main(String[] args) {
		
		System.out.println("�bienvenidos a la programacion en java!");

	}

}
