package cursoDeitel.Capitulo2.Ronald;
import javax.swing.JOptionPane;

public class Comparacion {

	public static void main(String[] args) {
		//variable donde se introducira lso datos del usuario
		String primerNumero;
		String segundoNumero;
		String resultado;
		
		//variables donde guardaremos los numeros
		
		int numero1;
		int numero2;
		
		
		//recivimos los resultados de los usuarios
		
		primerNumero = JOptionPane.showInputDialog("ingrese el primer numero entero");
		segundoNumero = JOptionPane.showInputDialog("ingrese el segundo numero entero");
		
		numero1 = Integer.parseInt(primerNumero);
		numero2 = Integer.parseInt(segundoNumero);
		
		//inicializar el resultado con una cadena vacia
		
		resultado = "";
		
		//comparamos los numeros con un if para saber el resultado que se va a moostrar
		
		if (numero1 == numero2) 
			resultado = resultado + numero1 + "==" + numero2;	
		
		if (numero1!=numero2)
			resultado = resultado + numero1 + "!=" + numero2;
		
		if (numero1 < numero2)
			resultado =  resultado + "\n" + numero1 + "<" + numero2;
		
		if(numero1> numero2)
			resultado = resultado + "\n" + numero1 + ">" + numero2;
		
		if (numero1 <= numero2)
			resultado = resultado + "\n" + numero1 + "<=" + numero2;
		
		if(numero1 >= numero2)
			resultado = resultado + "\n" + numero1 + ">=" + numero2;
		
		//ahora se mostrara los resultados
		
		JOptionPane.showMessageDialog(null, resultado, "Resultados de la comparacion", JOptionPane.INFORMATION_MESSAGE);
		
		System.exit(0);
		
		
	}

}
