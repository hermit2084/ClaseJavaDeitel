package cursoDeitel.Capitulo2.Ronald;
import javax.swing.JOptionPane;

public class Bienvenidos4 {

	public static void main(String[] args) {
		
		JOptionPane.showMessageDialog(null, "�bienvenidos\na\nla\nprogramacion\nen\njava!");
		
		System.exit(0);
				

	}

}
