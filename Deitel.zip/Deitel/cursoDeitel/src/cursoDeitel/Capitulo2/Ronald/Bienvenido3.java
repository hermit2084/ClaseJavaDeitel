package cursoDeitel.Capitulo2.Ronald;

public class Bienvenido3 {

	public static void main(String[] args) {
		
		System.out.println("�bienvenidos\na\nla\nprogramacion\nen\njava!");

	}

}
