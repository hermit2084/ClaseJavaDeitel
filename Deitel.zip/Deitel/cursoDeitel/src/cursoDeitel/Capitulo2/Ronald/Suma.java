package cursoDeitel.Capitulo2.Ronald;
//paquete de java

import javax.swing.JOptionPane;
public class Suma {

	public static void main(String[] args) {
		
		String primerNumero;
		String segundoNumero;
		
		int numero1;
		int numero2;
		int suma;
		
		//capturamos los dos numeros por el usuario
		
		primerNumero = JOptionPane.showInputDialog("escriba el primer numero entero");
		segundoNumero= JOptionPane.showInputDialog("escriba el segundo numero entero");
		
		
		//combertimos los numeros que ingreso el usuario a enteros por si no introduccen enteros
		numero1= Integer.parseInt(primerNumero);
		numero2= Integer.parseInt(segundoNumero);
		
		
		//sumamos los dos numeros enteros
		
		suma = numero1+numero2;
		
		//mostramos el resultado al usuario
		
		JOptionPane.showMessageDialog(null, "el resultado de la suma es" + suma,"Resultados", JOptionPane.PLAIN_MESSAGE);
		System.exit(0);
		
	}

}
